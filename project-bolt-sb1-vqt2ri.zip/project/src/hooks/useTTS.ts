import { Application } from '@nativescript/core';
import { useCallback } from 'react';

export function useTTS() {
    const speak = useCallback((text: string) => {
        if (Application.android) {
            // Android implementation
            const TextToSpeech = android.speech.tts.TextToSpeech;
            const tts = new TextToSpeech(Application.android.context, new TextToSpeech.OnInitListener({
                onInit: (status) => {
                    if (status !== TextToSpeech.ERROR) {
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                    }
                }
            }));
        } else if (Application.ios) {
            // iOS implementation
            const synthesizer = AVSpeechSynthesizer.new();
            const utterance = AVSpeechUtterance.speechUtteranceWithString(text);
            synthesizer.speakUtterance(utterance);
        }
    }, []);

    return { speak };
}