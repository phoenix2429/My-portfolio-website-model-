import { Application } from '@nativescript/core';
import { useState, useCallback } from 'react';

export function useVoiceRecognition() {
    const [isListening, setIsListening] = useState(false);
    const [results, setResults] = useState<string[]>([]);

    const startListening = useCallback(() => {
        if (Application.android) {
            // Android implementation
            const SpeechRecognizer = android.speech.SpeechRecognizer;
            const Intent = android.speech.RecognizerIntent;
            
            const speechRecognizer = SpeechRecognizer.createSpeechRecognizer(Application.android.context);
            const intent = new Intent(Intent.ACTION_RECOGNIZE_SPEECH);
            
            intent.putExtra(Intent.EXTRA_LANGUAGE_MODEL, Intent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(Intent.EXTRA_MAX_RESULTS, 1);
            
            speechRecognizer.startListening(intent);
            setIsListening(true);
            
            speechRecognizer.setRecognitionListener(new android.speech.RecognitionListener({
                onResults: (results: any) => {
                    const matches = results.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION);
                    setResults(Array.from(matches));
                    setIsListening(false);
                }
            }));
        } else if (Application.ios) {
            // iOS implementation
            const speechRecognizer = AVSpeechRecognizer.new();
            const request = SFSpeechAudioBufferRecognitionRequest.new();
            
            speechRecognizer.recognitionTaskWithRequestResultHandler(request, (result, error) => {
                if (result) {
                    setResults([result.bestTranscription.formattedString]);
                }
                if (error || result.isFinal) {
                    setIsListening(false);
                }
            });
        }
    }, []);

    const stopListening = useCallback(() => {
        setIsListening(false);
        // Implement platform-specific stop logic
    }, []);

    return {
        isListening,
        results,
        startListening,
        stopListening
    };
}