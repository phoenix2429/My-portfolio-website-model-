import { Application, Utils } from '@nativescript/core';
import { RouteProp } from '@react-navigation/core';
import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { FrameNavigationProp } from "react-nativescript-navigation";
import { useVoiceRecognition } from '../../hooks/useVoiceRecognition';
import { useTTS } from '../../hooks/useTTS';

type HomeScreenProps = {
    route: RouteProp<any, "Home">,
    navigation: FrameNavigationProp<any, "Home">,
};

export function HomeScreen({ navigation }: HomeScreenProps) {
    const { startListening, stopListening, results } = useVoiceRecognition();
    const { speak } = useTTS();

    React.useEffect(() => {
        speak("Welcome to Indoor Navigation. Tap anywhere to start voice commands.");
    }, []);

    const handleVoiceCommand = React.useCallback((command: string) => {
        const lowerCommand = command.toLowerCase();
        if (lowerCommand.includes("navigate") || lowerCommand.includes("go to")) {
            speak("Starting navigation mode");
            navigation.navigate("Navigation", { destination: command });
        } else if (lowerCommand.includes("settings")) {
            speak("Opening settings");
            navigation.navigate("Settings");
        }
    }, [navigation, speak]);

    React.useEffect(() => {
        if (results.length > 0) {
            handleVoiceCommand(results[0]);
        }
    }, [results, handleVoiceCommand]);

    return (
        <flexboxLayout style={styles.container}>
            <label className="text-3xl mb-8 font-bold text-center text-blue-600">
                Indoor Navigation Assistant
            </label>
            <button
                className="bg-blue-500 text-white p-4 rounded-lg mb-4 w-64 text-center"
                onTap={() => startListening()}
            >
                Start Voice Command
            </button>
            <button
                className="bg-red-500 text-white p-4 rounded-lg mb-4 w-64 text-center"
                onTap={() => stopListening()}
            >
                Stop Listening
            </button>
            <label className="text-lg text-center text-gray-600 mt-4">
                {results.length > 0 ? results[0] : "Tap to start voice commands"}
            </label>
        </flexboxLayout>
    );
}

const styles = StyleSheet.create({
    container: {
        height: "100%",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#ffffff",
    },
});